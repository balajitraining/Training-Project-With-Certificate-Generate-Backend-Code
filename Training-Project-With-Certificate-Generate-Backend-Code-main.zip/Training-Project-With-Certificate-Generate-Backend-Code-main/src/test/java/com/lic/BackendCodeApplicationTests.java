package com.lic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
